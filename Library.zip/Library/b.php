<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
  <li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
<li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
<li><a href="logout.php">Logout</a></li>
</ul></div>



<?php	
if($_SERVER['REQUEST_METHOD']=='POST')
{	

	include 'connect.php';
	
		$val=$_POST['book'];
		$sql = "SELECT * FROM book WHERE book_id='$val';";
		if ($result = $con->query($sql)) 
		{
			if ($result->num_rows > 0) 
			{
				while($row = $result->fetch_array()) 
				{
					$a=$row['book_id'];
					$b=$row['b_title'];
					$c=$row['author'];				
				}
				$sql1="select count(book_id) from book where b_title='$b';";

				if ($result1 = $con->query($sql1)) 
				{
					if ($result1->num_rows > 0) 
					{
						while($row1 = $result1->fetch_array()) 
						{
							$d=$row1['count(book_id)'];
							//echo$d;
						}
					}
					else
					{
						echo"no data";
					}
				}
				else
				{
					echo"mysql error";
				}	
			}
			 else 	
			{
				echo "<script>alert('No such book id found');document.location='b.html'</script>";
			}	
		}
	 	else 
		{
			echo "ERROR: Could not execute $sql. " . $con->error;
		}

	
echo"<fieldset>";
echo"<legend>Book Details</legend>";
echo "Book id<br>";
echo"<input type='text' value='$a' disabled><br><br>";
echo "Book Title:<br>";
echo "<input type='text'value='$b'disabled><br><br>";
echo"Book Author:<br>";
echo"<input type='text' value='$c' disabled><br><br>";
echo"No. of Copies<br><br>";
echo"<select disabled>";
echo"<option>$d<option>";
echo"</select>";
//echo"<select  id="m" disabled><br>

echo"</fieldset>";
	// close connection
	$con->close();
}
?>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi<br>@copyrights reserved</strong></p></footer>
</html>
