<?php
session_start();
?>
<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
  <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
<?php
	if(isset($_POST['locate']))
	{
		include 'connect.php';
		
		$name=$_POST['bk_name'];
		//echo$name;
		$sql="SELECT shelf FROM locate WHERE book_id IN (SELECT book_id FROM book WHERE b_title='$name')";
		if($result = $con->query($sql))
		{
			if($result-> num_rows>0)
			{
				echo"<fieldset>";
				echo"<legend>Locate Your Book</legend>";
				while($row = $result->fetch_array())
					{
						$shelf=$row['shelf'];
						echo"Book Name:";
						echo"<br>";
						echo"<input type='text' value='$name' disabled>";
 						echo"<br>";
						echo"Shelf No.:";
						echo"<br>";
						echo"<input type='text' value='$shelf' disabled>";
					}

			}
			else
			{
				echo "<script>alert('Spell the book correctly');document.location='locate.php'</script>";
			}
		}
	
	}

?>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
