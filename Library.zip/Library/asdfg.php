<?php 
include 'connect.php';
	//$x=$_POST['empid'];
	//echo$x;
	$sql="SELECT * FROM faculty WHERE emp_id='201'";
	if($result = $con->query($sql))
	{
		if($result-> num_rows>0)
		{
			echo"<fieldset>";
			echo"<legend>Return Book</legend>";
			echo"Employee Id:<br>";
			echo"<input type='text' value='201' disabled><br>";
			echo"<br><br>";
			echo"<table border=1 align='center'>";
			echo"<tr>";
			echo"<th></th>";
			echo"<th>Book Id</th>";
			echo"<th>Issue Date</th>";
			echo"<th>Date of return</th>";
			echo"</tr>";
			$j=1;
			while($row = $result->fetch_array())
			{
				$y=$row['book_id'];
				//echo$y;
				//echo"<br>";				
				$a=$row['issue_date'];				
				//echo$a;
				//echo"<br>";
				$z=$row['return_date'];
				//echo$z;
				//echo"<br>";
				
				echo"<tr>";
					echo"<td><input type='checkbox' name='check' value='$y'></td>";
					echo"<td><input type='text' value='$y' disabled></td>";
					echo"<td><input type='text' value='$a' disabled></td>";
					echo"<td><input type='text' value='$z' disabled></td>";
				echo"</tr>";
				$j=$j+1;
				//echo"<br>";
				//echo$j;			
			}	
			echo"</table>";
			echo"<br><br>";
			echo"<form method='post' action='return.php'>";
			echo"<input type='submit' value='Return' id='m' name='return'>";		
			echo"</fieldset>";
		}
	}



?>
