<?php
session_start();
//echo$_SESSION['username'];
?>
<html>

<head>

<title>DBIT LIBRARY</title>

<link rel="stylesheet" type="text/css" href="a.css"></link>
<link rel="stylesheet" type="text/css" href="d.css"></link>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
</head>
<body>
<img src="DonBosco.png" alt="error"  width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
 <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
</div><br><br>
<?php
if(isset($_POST['search']))
{	
	include 'connect.php';
	$name=$_POST['b_author'];
	//echo $a;	
	$sql="SELECT * FROM book WHERE author='$name'";
	$result=mysqli_query($con,$sql);
	if($result->num_rows>0)
	{
		echo"<fieldset>";
		echo"<legend>Your Book</legend>";
		echo"<br><br>";
		echo"<table border=1 align='center'>";
		echo"<tr>";
		echo"<th>Book Id</th>";
		echo"<th>Book Name</th>";
		echo"<th>Issued</th>";
		echo"<th>Return Date</th>";
		echo"</tr>";		
		while($row=$result->fetch_array())
		{
			$y=$row['book_id'];
			$a=$row['b_title'];
			//$z=$row['return_date'];
			$sql1="SELECT * FROM faculty WHERE book_id='$y'";
			$result1=mysqli_query($con,$sql1);
			if($result1->num_rows>0)
			{
				$b="Yes";
				while($row=$result1->fetch_array())
				{
					$c=$row['return_date'];
					//echo$c;
				}
			}
			else
			{
				$b="No";
				$c="Its in the Library";
			}
			echo"<tr>";
			echo"<td><input type='text' value='$y' disabled></td>";
			echo"<td><input type='text' value='$a' disabled></td>";
			echo"<td><input type='text' value='$b' disabled></td>";
			echo"<td><input type='text' value='$c' disabled></td>";
			echo"</tr>";
		}
	}
	else
	{
		echo "<script>alert('Spell the Author correctly');document.location='b_author.php'</script>";
	}
}
?>
</table>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
