<?php
require 'PHPMailer/PHPMailerAutoload.php'
$mail=new PHPMailer();
$mail->Host='smtp.gmail.com';
$mail->SMTPAuth='true';
$mail->Username='ashu.colosseum@gmail.com';
$mail->Password='8454858719';
$mail->SMTPSecure='tls';
$mail->Port=587;
$mail->SetFrom('Developer@cserockers.ga','Developer');
$mail->addAddress('xaviashu9714@gmail.com');
$mail->addReplyTo('Noreply@cserockers.ga','Info');
$mail->Subject='youtube';
$mail->Body='sample for youtube';
if($mail->send()){
echo'Mail Send';
}else{
echo'mail sending failed';
}
