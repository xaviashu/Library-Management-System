<?php
session_start();
?>
<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
  <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
<?php
if(isset($_POST['as']))
{
	include 'connect.php';
	$ei=$_POST['empid'];
	//echo$ei;
	$uname=$_POST['u_name'];
	//echo$uname;	
	$password=$_POST['pass'];
	$cpassword=$_POST['cpass'];
	$u_name=$_SESSION['username'];
	//echo$u_name;
	if($password==$cpassword)
	{	
		$sql="SELECT emp_id FROM login WHERE user_id='$u_name'";
		$result=mysqli_query($con,$sql);
		if(($result->num_rows)>0)
		{
			while($row=$result->fetch_array())
				{
					$o_id=$row['emp_id'];	
					//echo"<br>";			
					//echo $o_id;			
				}
		}
		else
		{
			echo"No result found";
		}
		$sql1="UPDATE login SET user_id='$uname',password='$password',emp_id='$ei' WHERE emp_id='$o_id'";
		$reult1=mysqli_query($con,$sql1);
	
		$sql2="SELECT name FROM faculty_name WHERE emp_id='$o_id'";
		$result2=mysqli_query($con,$sql2);
		if(($result2->num_rows)>0)
		{
			while($row=$result2->fetch_array())
				{
					$name=$row['name'];	
					//echo"<br>";			
					//echo $name;			
				}
		}
		$sql3="UPDATE faculty_name SET emp_id='$ei' WHERE name='$name'";
		$result3=mysqli_query($con,$sql3);
		
		$sql4="UPDATE faculty SET emp_id='$ei' WHERE emp_id='$o_id'";
		$result4=mysqli_query($con,$sql4);
	}
	else
	{
		echo "<script>alert('Password and Confirm Password doesn't match');document.location='locate.php'</script>";
	}
}
?>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
