<?php
session_start();
?>
<html>
<head>
<title>Login Page</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="register.php">Sign Up</a></li> 
	<li><a href="login.php">Login</a></li>
</ul>
<fieldset>
<legend>Login</legend>
<form name="myform" action="login.php" method="post">
Username:<br>
<input name="u_name" type="text" required></input><br><br>
Password:<br>
<input name="pass" type="password" required></input><br><br>
<input type="submit" name="login" value="Login"></input>
<?php
if(isset($_POST['login']))
{
	include 'connect.php';	
	$username=$_POST['u_name'];
	$password=$_POST['pass'];
	//echo $username;
	//echo $password;
	$sql= " SELECT * FROM login WHERE user_id='$username' AND password='$password'";
	$result=mysqli_query($con,$sql);
	if(($result->num_rows)>0)
	{
		$_SESSION['username']=$username;
		if($username=="library" && $password=="dbit")
		{
			header('location:a.html');
		}
		else
		{		
			header('location:home1.php');	
		}	
	}
	else
	{
		$s= " SELECT * FROM login WHERE user_id='$username'";
		$r=mysqli_query($con,$s);
		if(($r->num_rows)>0)
		{
			//$a=$row['user_id'];
			echo '<script type="text/javascript">alert("Incorrect password")</script>';
		
		}	
		else
		{
			echo '<script type="text/javascript">alert("user in invalid")</script>';		
		}
	}
}	
?>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
