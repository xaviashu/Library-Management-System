<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
  <li><a href="e.html">Return Book</a></li>

</ul></div>
<?php
if(isset($_POST['simran']))
{
	include 'connect.php';
	$x=$_POST['empname'];
	//echo $x;
	$sql="SELECT count(emp_id) FROM faculty WHERE emp_id IN ( SELECT emp_id FROM faculty_name WHERE name='$x')";
	if($result = $con->query($sql))
	{
		if($result-> num_rows>0)
		{
			while($row = $result->fetch_array())
			{
				$y=$row['count(emp_id)'];
			}
			if($y!=0){
			echo"<fieldset>";
			echo"<legend>Book Details</legend>";
			echo"Name of the faculty:<br>";
			echo"<input type='text' value='$x' disabled>";
			echo"<br><br>";
			echo"No. of books issued:<br>";
			echo"<select disabled>";
			echo"<option>$y<option>";
			echo"</select>";
			echo"<br><br>Book details:<br>";	
			echo"<table align='center'>";
			echo"<tr>";
			echo"<th>Book Id</th>";
			echo"<th>Book Title</th>";
			echo"<th>Book Author</th>";
			echo"<th>Date of issue</th>";
			echo"<th>Return Date</th>";
			echo"</tr>";}
		}
		if($y==0)
		{
			echo "<script>alert('No Book issued by Faculty');document.location='f.html'</script>";
		}
		
		
	}
	else
	{
		echo "<script>alert('Error in sql qwery');document.location='f.html'</script>";
	}

	$s="SELECT * FROM faculty WHERE emp_id IN ( SELECT emp_id FROM faculty_name WHERE name='$x')";
	if($r = $con->query($s))
	{
		if($r-> num_rows>0)
		{
			while($row = $r->fetch_array())
			{
				$u=$row['book_id'];
				//echo $u;
				//echo"<br>";
				$sq="SELECT * FROM book WHERE book_id='$u'";
				if($re = $con->query($sq))
				{
					if($re-> num_rows>0)
					{
						while($row = $re->fetch_array())
						{
							$v=$row['b_title'];
							//echo $v;
							//echo"<br>";
							$w=$row['author'];
							//echo $w;
							//echo"<br>";


						}
					}
					else
					{
						echo"nothing";	
					}
				}
				else
				{
					echo"error in sql querry";	
				}
				$sqq="SELECT * FROM faculty WHERE book_id='$u'";
				if($ree = $con->query($sqq))
				{
					if($ree-> num_rows>0)
					{
						while($row = $ree->fetch_array())
						{
							$p=$row['issue_date'];
							//echo $v;
							//echo"<br>";
							$q=$row['return_date'];
							//echo $w;
							//echo"<br>";


						}
					}
					else
					{
						echo"nothing";	
					}
				}
				else
				{
					echo"error in sql querry";	
				}
				echo"<tr>";
				echo"<td><input type='text' value='$u' disabled></td>";
				echo"<td><input type='text' value='$v' disabled></td>";
				echo"<td><input type='text' value='$w' disabled></td>";
				echo"<td><input type='text' value='$p' disabled></td>";
				echo"<td><input type='text' value='$q' disabled></td>";
				echo"</tr>";
			}
		}
		else
		{
			echo '<script type="text/javascript">alert("No result found")</script>';	
		}	
	}
	else
	{
		echo"error in sql querry";	
	}


echo"</table>";
echo"</fieldset>";
}
?>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi<br>@copyrights reserved</strong></p></footer>
</html>
