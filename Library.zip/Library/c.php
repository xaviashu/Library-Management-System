<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

 <li><a href="a.html">Home</a></li>
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
  <li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
</ul></div>
<fieldset>
<legend>Maintain Book Record</legend>
<?php
if(isset($_POST['as']))
{
	include 'connect.php';
	
	$ei=$_POST['empid'];

	$bi=$_POST['bid'];

	$bt=$_POST['btitle'];

	$d1=$_POST['date'];

	$d2=$_POST['date1'];
	$sql="INSERT INTO faculty VALUES ('$ei','$bi','$d1','$d2')";
	if($result=$con->query($sql))
	{
		echo "<script>alert('Book issued to employee=$ei');document.location='c.html'</script>";
	}
	else
	{
		echo "<script>alert('Error');document.location='c.html'</script>";
	}
}
?>
</fieldset>

</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>	
