<?php
echo "<script>alert('There are no fields to generate a report');document.location='a.html'</script>";
?>
