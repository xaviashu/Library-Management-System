<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
  <li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
<li><a href="logout.php">Logout</a></li>
</ul></div>
<?php
if(isset($_POST['simimerijaan']))
{

	include 'connect.php';
	$x=$_POST['empid'];
	//echo$x;
	$sql="SELECT * FROM faculty WHERE emp_id='$x'";
	if($result = $con->query($sql))
	{
		if($result-> num_rows>0)
		{
			echo"<fieldset>";
			echo"<legend>Return Book</legend>";
			echo"<form method='post' action='return.php'>";
			echo"Employee Id:<br>";
			echo"<input type='text' value='$x' disabled><br>";
			echo"<br><br>";
			echo"<table border=1 align='center'>";
			echo"<tr>";
			echo"<th></th>";
			echo"<th>Book Id</th>";
			echo"<th>Issue Date</th>";
			echo"<th>Date of return</th>";
			echo"</tr>";
			$j=1;
			while($row = $result->fetch_array())
			{
				$y=$row['book_id'];
				//echo$y;
				//echo"<br>";				
				$a=$row['issue_date'];				
				//echo$a;
				//echo"<br>";
				$z=$row['return_date'];
				//echo$z;
				//echo"<br>";
				
				echo"<tr>";
					echo"<td><input type='checkbox' name='check[]' value='$y' required></td>";
					echo"<td><input type='text' value='$y' disabled></td>";
					echo"<td><input type='text' value='$a' disabled></td>";
					echo"<td><input type='text' value='$z' disabled></td>";
				echo"</tr>";
				$j=$j+1;
				//echo"<br>";
				//echo$j;			
			}	
			echo"</table>";
			echo"<br><br>";
			echo"<input type='submit' value='Return' id='m' name='return'>";		
			echo"</form>";			
			echo"</fieldset>";
		}
		else
		{
			echo "<script>alert('No Book issued by the faculty');document.location='e.html'</script>";		
		}
	}
}

?>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>

</html>

