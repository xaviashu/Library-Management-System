<html>
<head>
<title>Registration Page</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="register.php">Sign Up</a></li> 
	<li><a href="login.php">Login</a></li>
</ul>
<fieldset>
<legend>Registration</legend>
<form name="myform" action="register.php" method="post">
Employee Id:<br>
<input name="emp" type="text" required></input><br><br>
Name:<br>
<input name="name" type="text" required></input><br><br>
Username:<br>
<input name="uname" type="text" required></input><br><br>
Password:<br>
<input name="pass" type="password"></input><br><br>
Confirm Password:<br>
<input name="cpass" type="password"></input><br><br>
<input type="submit" name="sub" value="Register"></input>
</form>
</fieldset>
<?php
if(isset($_POST['sub']))
{
	include 'connect.php';	
	$username=$_POST['uname'];
	$password=$_POST['pass'];
	$cpassword=$_POST['cpass'];
	$emp=$_POST['emp'];
	$name=['name'];
	if($password==$cpassword)
	{
		$query="SELECT * FROM login WHERE user_id='$username'";
		$result= mysqli_query($con,$query);
		if(mysqli_num_rows($result)>0)
		{
			echo '<script type="text/javascript">alert("User already exist try another user name")</script>';
		}
		else
		{
			$query="INSERT into login values('$username','$password','$emp')";
			$query_run=mysqli_query($con,$query);
			if($query_run)
			{
				echo '<script type="text/javascript">alert("User registered go to login page")</script>';
			}
			else
			{
				echo '<script type="text/javascript">alert("Errror")</script>';
			}
			$sql="INSERT INTO faculty_name VALUES('$emp','$name')";
			$result=mysqli_query($con,$sql);
					
		}
	}	
	else
	{
	echo '<script type="text/javascript">alert("password and confirmed password doesnt match")</script>';
	}

}
	
?>

