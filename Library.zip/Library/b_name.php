<?php
session_start();
//echo$_SESSION['username'];
?>
<html>

<head>

<title>DBIT LIBRARY</title>

<link rel="stylesheet" type="text/css" href="a.css"></link>
<link rel="stylesheet" type="text/css" href="d.css"></link>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
</head>

<body>
<img src="DonBosco.png" alt="error"  width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
 <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
</div><br><br>

<fieldset>
<legend>Search Your Book</legend>
<form name="myform" action="bk_name.php" method="post">
Book Name:<br>
<input name="b_name" type="text" required></input><br><br>
<input type="submit" id ="m" name="search" value="Search"></input
</form>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
