<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
  <li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
<li><a href="logout.php">Logout</a></li>
</ul></div>
</html>
<?php
if(isset($_POST['return']))
{
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	//echo 'you have added the following tools to your shopping cart:';
	foreach ($_POST['check'] as $b_id) {
		include 'connect.php';		
		$sql="DELETE FROM faculty WHERE book_id='$b_id'";
		if($result = $con->query($sql))
		{
			echo "<script>alert('Book Returned');document.location='e.html'</script>";				
		}
		else
		{	
			echo "<script>alert('Try again');document.location='e.html'</script>";		
		}
	}
}
}
?>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>

</html>


