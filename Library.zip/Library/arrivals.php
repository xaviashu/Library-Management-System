<html>

<head>

<title>DBIT LIBRARY</title>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" type="text/css" href="a.css">
</link>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
</head><body>
<img src="DonBosco.png" alt="error"  width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<style>
table{
border:10;
text-align:center;
color:yellow;
background-color:red;
}

</style>
<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
  <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
<?php
	include 'connect.php';



$sql="SELECT * FROM new_arrivals";
$result=mysqli_query($con,$sql);
$x=1;
if($result->num_rows>0)
{
	echo"<fieldset>";
	echo"<legend>New Arrivals</legend>";
	echo"<table border=1 align='center' >";
	echo"<tr>";
	echo"<th width='20%'>Snapshot</th>";
	echo"<th>Book Name</th>";
	echo"<th>Author</th>";
	echo"<th>Description</th>";
	echo"<th>Available From</th>";
	echo"<th>No. of Copies</th>";
	echo"</tr>";		
	while($row=$result->fetch_array())
	{
		$name=$row['b_name'];	
		$author=$row['b_author'];
		$des=$row['descr'];
		$date=$row['a_date'];
		$number=$row['copies'];
		echo"<tr>";
		echo"<td><img src='upload1.php?id=$x' height='10%' width='20%'>";	
		echo"<td><p>$name</p></td>";
		echo"<td><p>$author</p></td>";
		echo"<td><p>$des</p></td>";
		echo"<td><p>$date</p></td>";
		echo"<td><p>$number</p></td>";
		echo"</tr>";
		$x=$x+1;
	}
	echo"</table>";
	echo"</fieldset>";
}
?>

</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
