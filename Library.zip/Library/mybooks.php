<?php
session_start();
?>
<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
  <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
<?php
	include 'connect.php';
	$x=$_SESSION['username'];
	//echo$x;
	echo"<br>";
	$sq="SELECT emp_id FROM login WHERE user_id='$x'";
	if($result = $con->query($sq))
	{
		if($result-> num_rows>0)
		{
			while($ro = $result->fetch_array())
			{
				$xy=$ro['emp_id'];
				//echo$xy;		
			}
			$sql="SELECT * FROM faculty WHERE emp_id='$xy'";
			if($result = $con->query($sql))
			{
				if($result-> num_rows>0)
				{
					echo"<fieldset>";
					echo"<legend>My Books</legend>";
					echo"Employee Id:<br>";
					echo"<input type='text' value='$xy' disabled><br>";
					echo"<br><br>";
					echo"<table border=1 align='center'>";
					echo"<tr>";
					echo"<th>Book Id</th>";
					//echo"<th>Book Title</th>";
					echo"<th>Issue Date</th>";
					echo"<th>Return Date</th>";
					echo"</tr>";
					while($row = $result->fetch_array())
					{
						$y=$row['book_id'];
						//echo$y;
						//echo"<br>";				
						$a=$row['issue_date'];				
						//echo$a;
						//echo"<br>";
						$z=$row['return_date'];
						//echo$z;
						//echo"<br>";
						$sqli="SELECT b_title FROM book WHERE book_id='$y'";
						/*if($res=$con->query($sqli)		
						{
							if($res->num_rows>0)
							{
								while($ro=$res->fetch_array())
								{
									$o=$ro['b_title'];
								}
							}
						}*/
						echo"<tr>";
						echo"<td><input type='text' value='$y' disabled></td>";
						//echo"<td><input type='text' value='$o' disabled></td>";
						echo"<td><input type='text' value='$a' disabled></td>";
						echo"<td><input type='text' value='$z' disabled></td>";
						echo"</tr>";			
					}	


				}
				else
				{
					echo '<script type="text/javascript">alert("NO Book Issued")</script>';
				}
					
			}
		}
else
{
echo"no data";
}
	}
else{
echo"error";
}
?>
</table>
</fieldset>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
