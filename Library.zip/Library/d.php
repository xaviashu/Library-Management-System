<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
  <li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
</ul></div>
<?php	
if(isset($_POST['ashu']))
{	
	include 'connect.php';
	$a=$_POST['bd'];
	//echo $a;	
	$sql="SELECT * FROM faculty WHERE book_id='$a'";
	$result=mysqli_query($con,$sql);
	if($result->num_rows>0)
	{
		while($row=$result->fetch_array())
		{
			$name=$row['emp_id'];	
			//echo $name;	
			//echo"<br>";
			$y=$row['issue_date'];
			//echo $y;		
		}	
		$s="SELECT * FROM faculty_name WHERE emp_id='$name'";
		$r=mysqli_query($con,$s);
		if($r->num_rows>0)
		{
			while($row=$r->fetch_array())
			{
				$n=$row['name'];	
				//echo"<br>";			
				//echo $n;			
			}	
		}		
		echo"<fieldset>";
		echo"<legend>Search BY BID</legend>";
		echo"<br>Book id:<br>";
		echo"<input type='text' value='$a' disabled><br><br>";
		echo"Faculty Name:<br>";
		echo"<input type='text' value='$n' disabled><br>";
		echo"<br>Date of issue:<br>";
		echo"<input type='date' value='$y' disabled><br>";
		echo"</fieldset>";
	}		
		
	/*else
	{
		echo"no match found";
	}*/
		
		
	else
	{
		echo "<script>alert('Book Id not found');document.location='d.html'</script>";
	}
}
echo"</body>";
echo"<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>";
echo"</html>";
?>
