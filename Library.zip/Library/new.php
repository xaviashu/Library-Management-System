<?php
session_start();
?>
<html>
<head>
<title>DBIT LIBRARY</title>
<head>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
<link rel="stylesheet" href="d.css" type="text/css"></link>
<link rel="stylesheet" href="a.css" type="text/css"></link>
</head>
<body>
<img src="DonBosco.png" alt="error" width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>
<div>

<ul id="u">

   <li><a href="a.html">Home</a></li> 
	<li><a href="b.html">Book Details</a></li>
  <li><a href="c.html">Maintain Book Record</a></li>
  <li class="dropdown">
    <a href="#" class="dropbtn">Search BY</a>
    <div class="dropdown-content">
      <a href="d.html">Book ID</a>
      <a href="f.html">Faculty Name</a>
    </div>
  </li>
<li><a href="e.html">Return Book</a></li>
<li><a href="new.html">New Arrivals</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul></div>
<?php	
if(isset($_POST['new_value']))
{	
	include 'connect.php';
	$bn=$_POST['bk_name'];
	//echo$bn;	
	$ba=$_POST['bk_author'];
	//echo$ba;
	$d=$_POST['des'];
	//echo$d;
	$da=$_POST['date1'];
	$n=$_POST['number'];
	//echo$da;
	$sql="INSERT INTO new_arrivals VALUES('$bn','$ba','$d','$da','$n')";
	$check = getimagesize($_FILES["image"]["tmp_name"]);
	$image = $_FILES['image']['tmp_name'];
	$imgContent = addslashes(file_get_contents($image));
	$dataTime = date("Y-m-d H:i:s");
	$sql1 = "INSERT into images (image, created) VALUES ('$imgContent', '$dataTime')";
	if(($result=$con->query($sql))&&($result1=$con->query($sql1)))
	{
		echo "<script>alert('new record created');document.location='new.html'</script>";

	
	}
	else
	{
		echo "<script>alert('Data not inserted due:'.mysqli_error($con));</script>";
	
	}
}
?>
</body>
</html>
