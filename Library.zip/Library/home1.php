<?php
session_start();
//echo$_SESSION['username'];
?>
<html>

<head>

<title>DBIT LIBRARY</title>

<link rel="stylesheet" type="text/css" href="a.css">
</link>
<link rel="icon" href="DBIT_logo(1).png" type="image/png">
</link>
</head>
<!--<style>
p{
color:yellow;
}
h1{
color:yellow;
}
h3{
color:yellow;
}
body{
background:red;
}
</style>-->
<body>
<img src="DonBosco.png" alt="error"  width="100%">
</img><hr>
<h1 align="center"><b><u><i>DBIT FACULTY LIBRARY MANAGEMENT SYSTEM</i></u></b></h1>

<ul id="u">

   <li><a href="home1.php">Home</a></li> 
	<li><a href="mybooks.php">My Book</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Search By</a>
    <div class="dropdown-content">
      <a href="b_name.php">Book Name</a>
      <a href="b_author.php">Book Author</a>
    </div>
  </li> 
 <li><a href="arrivals.php">New Arrivals</a></li>
  <li><a href="locate.php">Locate</a></li>
<li class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
      <a href="profile.php">Edit Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </li>
</ul></div>
</div><br><br>
<div align="center">
<div align="left" style="width:30%;"><img class="slides" src="slide1.jpg" width="100%">
<img class="slides" src="slide2.jpg" width="100%">
<img class="slides" src="19.jpg" width="100%">
</div></div>
<script>
var index = 0;
ashu();
function ashu() {
    var i;
    var x = document.getElementsByClassName("slides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    index++;
    if (index > x.length) {index = 1}    
    x[index-1].style.display = "block";  
    setTimeout(ashu, 2000); // Change image every 2 seconds
}
</script>
<div align="right">
<div align="left" style="width:30%;"><h3><u>About  Library</u></h3><img src="bk-1.jpg" height=30% width=100%></img><br><br><p><i><q>The <span style="color:green;font-weight:bold">DBIT</span> Library (Learning Resource Centre) is an Open Access Systematized library. The Library has developed an excellent collection of books, journals and non-book material covering the principle fields of interest in engineering and related subjects like Electronics & Telecommunication, Computer Science, Communication, Mechanical, etc. The library has a good collection of Project reports, rare Books, besides these, there are books of Social Sciences, general interest and Certifications like MSCE and it has a separate collection of some audiovisual material. It maintains separate collections of Reference Books, Bound volumes of journals. There are more than 12000 Books, 58 Print Journals in which 30 are International and 28 National Scopes. Library has online subscription for more than 20 IEEE & ACM Journals. A separate collection of more than 1700 CDs, Floppies and DVDs Covering a vast range of subjects like Software, Communication Skills, Management skills, Personal Management, Historical Timeline, Aptitude test GATE, GRE and etc.

Ekalavya, OnlineTutorials, Workbooks, Book-bank Books, University syllabi, Previous Year question papers/Question Banks, Old Project Reports, Manuals, Handbooks and Newspapers are also available in library.

Library services are automated using KOHA Software, OPAC and Web-OPAC are available for users to search the status of library material. Barcode Technology is been implemented in library transactions.

Computers with multimedia facilities and Internet facilities are available during the Library working Hours to students and staff. He Librarys collection and its services reflect not only the syllabus requirement but also the present and advance.

DBIT Library is not just a storehouse of resources. It turns the frequent user into RESOURCEFUL Person.</i></q></p>
<p id="demo"></p>

<script>
document.getElementById("demo").innerHTML = Date();
</script>
</div></div>
<input type="text" disabled hidden	></input>
</body>
<footer><p><strong> Designed By Ashutosh Tripathi</strong></p></footer>
</html>
